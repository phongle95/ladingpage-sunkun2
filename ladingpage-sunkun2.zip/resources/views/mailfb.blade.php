<h3>Tên Khách Hàng : {{$name}}</h3>
<br>
<h3>Số Điện Thoại : {{$sdt}}</h3>
<br>
<h3>Nội Dung : {{$noiDung}}</h3>
